import { Navbar } from '@/components/navbar';
import { Footer } from '@/components/footer';
import { FloatingCTA } from '@/components/floating-cta';
import Link from 'next/link';

export default function Home() {
  return (
    <>
      <Navbar />
      <main className="overflow-hidden">
        {/* Hero Section */}
        <section className="min-h-screen flex items-center justify-center relative pt-20 pb-20 overflow-hidden">
          <div className="absolute inset-0 -z-10">
            <div className="absolute top-20 right-10 w-96 h-96 bg-primary/15 rounded-full blur-3xl opacity-40 animate-float" />
            <div className="absolute bottom-20 left-10 w-96 h-96 bg-accent/15 rounded-full blur-3xl opacity-40 animate-float" style={{animationDelay: '1s'}} />
            <div className="absolute top-1/2 left-1/4 w-80 h-80 bg-primary/10 rounded-full blur-3xl opacity-30 animate-float" style={{animationDelay: '2s'}} />
          </div>

          <div className="container-premium text-center relative z-10">
            <div className="inline-block mb-8 animate-slide-up">
              <span className="px-4 py-2 rounded-full border border-primary/50 text-primary text-sm font-semibold uppercase tracking-wider animate-pulse-glow">
                Premium Wealth Building Platform
              </span>
            </div>

            <h1 className="heading-premium mb-8 text-gradient animate-slide-up" style={{animationDelay: '0.1s'}}>
              Build Generational<br/>Wealth Through<br/>Strategic Land Investment
            </h1>

            <p className="subheading-premium mb-16 text-center mx-auto max-w-2xl animate-slide-up" style={{animationDelay: '0.2s'}}>
              Join 500+ institutional investors securing premium land plots with proven 156% appreciation in just 18-24 months. Fully verified titles, transparent structures, and institutional-grade security.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-20 animate-slide-up" style={{animationDelay: '0.3s'}}>
              <Link href="/investment" className="cta-emphasis">
                Explore Investment Tiers
              </Link>
              <a
                href="https://wa.me/2348099955884?text=I'm%20interested%20in%20premium%20land%20investment%20at%20Greenfield%20Megavision"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-secondary animate-invest-bounce"
              >
                Consult Expert Now
              </a>
            </div>

            {/* Key Investment Metrics */}
            <div className="grid grid-cols-3 gap-4 md:gap-8 max-w-4xl mx-auto">
              {[
                { value: '156%', label: 'Average ROI' },
                { value: '500+', label: 'Verified Investors' },
                { value: '18-24M', label: 'Return Timeline' },
              ].map((stat, idx) => (
                <div key={idx} className="investment-card animate-card-appear" style={{animationDelay: `${0.4 + idx * 0.1}s`}}>
                  <p className="stat-value animate-invest-bounce">{stat.value}</p>
                  <p className="stat-label mt-2">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Mission & Vision */}
        <section className="py-20">
          <div className="container-premium">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-5xl mx-auto mb-20">
              <div className="cta-card">
                <h3 className="text-2xl font-bold gradient-text mb-4">Our Vision</h3>
                <p className="text-muted leading-relaxed">
                  "To redefine modern real estate investment through innovative developments, integrity, and wealth-building opportunities for generations."
                </p>
              </div>
              <div className="cta-card">
                <h3 className="text-2xl font-bold gradient-text mb-4">Our Mission</h3>
                <p className="text-muted leading-relaxed">
                  "To develop high-value properties that combine affordability, security, and profitability while maintaining trust, professionalism, and customer satisfaction."
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Why Choose Section */}
        <section className="py-20 bg-secondary/5 relative overflow-hidden">
          <div className="absolute inset-0 -z-10">
            <div className="absolute bottom-0 right-0 w-96 h-96 bg-primary/10 rounded-full blur-3xl opacity-20" />
          </div>
          
          <div className="container-premium relative z-10">
            <div className="text-center mb-20">
              <h2 className="heading-invest mb-4 animate-slide-up">Why Institutional Investors Choose Us</h2>
              <p className="subheading-premium text-center animate-slide-up" style={{animationDelay: '0.1s'}}>
                Institutional-grade investment with transparent operations and proven returns
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                { icon: '🏛️', title: 'Legal Grade Verification', desc: 'Government-registered titles with full legal backing and insurance coverage' },
                { icon: '📈', title: 'Documented Performance', desc: 'Verified 156% appreciation verified through multiple independent audits' },
                { icon: '💳', title: 'Institutional Payment Terms', desc: 'Flexible structures: lump sum, monthly, quarterly, or seasonal payments' },
                { icon: '🏗️', title: 'Active Value Creation', desc: 'Premium infrastructure development with ongoing community enhancements' },
                { icon: '🛡️', title: 'Escrow Protection', desc: 'All investor funds held in independent escrow with zero hidden costs' },
                { icon: '👨‍💼', title: 'Dedicated Account Management', desc: '24/7 institutional support with dedicated account managers' },
              ].map((item, idx) => (
                <div 
                  key={idx} 
                  className="investment-card animate-card-appear group"
                  style={{animationDelay: `${0.1 + idx * 0.05}s`}}
                >
                  <div className="text-5xl mb-4 group-hover:scale-110 transition-transform duration-300">{item.icon}</div>
                  <h3 className="text-xl font-bold mb-3 text-foreground">{item.title}</h3>
                  <p className="text-muted text-sm leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20">
          <div className="container-premium text-center">
            <h2 className="section-heading mb-6">Ready to Build Your Wealth?</h2>
            <p className="section-subheading mb-12">
              Get started today and join 500+ successful investors in our community
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <a
                href="https://wa.me/2348099955884?text=I%20want%20to%20learn%20more%20about%20Greenfield%20Megavision%20investment"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary"
              >
                Chat on WhatsApp
              </a>
              <Link href="/contact" className="btn-secondary">
                Send Message
              </Link>
              <Link href="/plots" className="btn-secondary">
                View Plots
              </Link>
            </div>

            {/* Social Links */}
            <p className="text-sm text-muted mb-6">Follow us for updates and exclusive opportunities</p>
            <div className="flex gap-6 justify-center">
              <a
                href="https://www.instagram.com/offical_greenfieldmegavision"
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-2 rounded-full border border-primary/30 text-primary hover:bg-primary hover:text-primary-foreground transition-all duration-300 text-sm font-semibold"
              >
                Instagram
              </a>
              <a
                href="https://www.facebook.com/greenfieldmegavision"
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-2 rounded-full border border-primary/30 text-primary hover:bg-primary hover:text-primary-foreground transition-all duration-300 text-sm font-semibold"
              >
                Facebook
              </a>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <FloatingCTA />
    </>
  );
}
