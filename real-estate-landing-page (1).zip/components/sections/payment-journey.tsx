'use client';

import { CheckCircle, FileText, Home, DollarSign } from 'lucide-react';

export function PaymentJourney() {
  const steps = [
    {
      number: 1,
      title: 'Initiate Investment',
      description: 'Choose your plot size and payment plan',
      icon: DollarSign,
      details: [
        'Select property tier',
        'Choose payment timeline',
        'Review total cost',
        'Confirm via WhatsApp/Email',
      ],
    },
    {
      number: 2,
      title: 'Legal Documentation',
      description: 'Secure your investment with verified titles',
      icon: FileText,
      details: [
        'Land verification completed',
        'Title documentation prepared',
        'Government registration initiated',
        'Lawyer assigned for support',
      ],
    },
    {
      number: 3,
      title: 'Ownership Transfer',
      description: 'Formal transfer of rights to your name',
      icon: Home,
      details: [
        'Plot officially registered',
        'Certificate of occupancy issued',
        'Documents transferred securely',
        'Full ownership confirmed',
      ],
    },
    {
      number: 4,
      title: 'Value Realization',
      description: 'Watch your investment grow and monetize',
      icon: CheckCircle,
      details: [
        'Ongoing estate development',
        'Demand and appreciation grow',
        'Resale opportunities emerge',
        'Profit realization',
      ],
    },
  ];

  return (
    <section className="py-20 md:py-32 bg-gradient-to-b from-white to-primary/5">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="section-heading mb-4">Your Investment Journey</h2>
          <p className="section-subheading mx-auto">
            Four transparent steps from investment to profit realization
          </p>
        </div>

        {/* Timeline */}
        <div className="relative mb-16 animate-slide-up">
          {/* Connecting Line */}
          <div className="hidden md:block absolute top-20 left-0 right-0 h-1 bg-gradient-to-r from-primary via-accent to-primary/30"></div>

          {/* Steps */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <div key={index} className="relative">
                  {/* Step Circle */}
                  <div className="flex justify-center mb-8">
                    <div className="relative w-20 h-20 bg-white rounded-full border-4 border-primary flex items-center justify-center z-10 shadow-lg">
                      <Icon className="w-10 h-10 text-primary" />
                    </div>
                  </div>

                  {/* Step Content */}
                  <div className="card-premium text-center">
                    <h3 className="text-lg font-bold text-foreground mb-2">{step.title}</h3>
                    <p className="text-sm text-muted mb-4">{step.description}</p>

                    {/* Details */}
                    <div className="space-y-2 pt-4 border-t border-border text-left">
                      {step.details.map((detail, detailIndex) => (
                        <div key={detailIndex} className="flex items-start gap-2">
                          <CheckCircle className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                          <span className="text-xs text-foreground">{detail}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Timeline Breakdown */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-fade-in">
          <div className="card-premium-lg">
            <h3 className="text-2xl font-bold mb-6 text-foreground">Typical Timeline</h3>
            <div className="space-y-4">
              <div className="flex gap-4">
                <div className="flex flex-col items-center">
                  <div className="w-3 h-3 bg-primary rounded-full mt-2"></div>
                  <div className="w-0.5 h-12 bg-border"></div>
                </div>
                <div>
                  <p className="font-semibold text-foreground">Days 1-3: Initial Setup</p>
                  <p className="text-sm text-muted">Documentation review and approval</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex flex-col items-center">
                  <div className="w-3 h-3 bg-primary rounded-full mt-2"></div>
                  <div className="w-0.5 h-12 bg-border"></div>
                </div>
                <div>
                  <p className="font-semibold text-foreground">Week 1-2: Registration</p>
                  <p className="text-sm text-muted">Government verification and title processing</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex flex-col items-center">
                  <div className="w-3 h-3 bg-primary rounded-full mt-2"></div>
                  <div className="w-0.5 h-12 bg-border"></div>
                </div>
                <div>
                  <p className="font-semibold text-foreground">Week 3-4: Transfer</p>
                  <p className="text-sm text-muted">Ownership documentation and handover</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex flex-col items-center">
                  <div className="w-3 h-3 bg-primary rounded-full mt-2"></div>
                </div>
                <div>
                  <p className="font-semibold text-foreground">18-24 Months: Growth & Monetization</p>
                  <p className="text-sm text-muted">Estate development and value appreciation</p>
                </div>
              </div>
            </div>
          </div>

          <div className="card-premium-lg">
            <h3 className="text-2xl font-bold mb-6 text-foreground">Total Cost Breakdown</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-baseline pb-3 border-b border-border">
                <span className="text-muted">Plot Cost</span>
                <span className="text-foreground font-semibold">₦2,800,000</span>
              </div>
              <div className="flex justify-between items-baseline pb-3 border-b border-border">
                <span className="text-muted">Legal Documentation</span>
                <span className="text-foreground font-semibold">₦0</span>
              </div>
              <div className="flex justify-between items-baseline pb-3 border-b border-border">
                <span className="text-muted">Registration Fees</span>
                <span className="text-foreground font-semibold">₦0</span>
              </div>
              <div className="flex justify-between items-baseline pb-3 border-b border-border">
                <span className="text-muted">Hidden Charges</span>
                <span className="text-foreground font-semibold">None</span>
              </div>
              <div className="flex justify-between items-baseline pt-4 bg-primary/5 px-4 py-3 rounded-lg">
                <span className="font-bold text-foreground">Total Investment</span>
                <span className="text-2xl font-bold text-primary">₦2,800,000</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
