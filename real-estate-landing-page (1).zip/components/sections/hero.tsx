'use client'

import { Button } from '@/components/ui/button'
import { MessageCircle, Eye, Instagram } from 'lucide-react'
import Link from 'next/link'
import Image from 'next/image'

export default function HeroSection() {
  const whatsappLink = "https://wa.me/2348099955884?text=Hi%20Greenfield%20Megavision!%20I'm%20interested%20in%20learning%20more%20about%20your%20land%20plots."

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background with gradient overlay */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/hero-property.jpg"
          alt="Greenfield Megavision Estate"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/40"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 py-20 text-center">
        <div className="animate-fade-in space-y-6">
          {/* Logo/Brand */}
          <div className="mb-8">
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-2 text-balance">
              Secure Land Before<br className="hidden sm:block" />
              <span className="text-green-400">the Next Price Increase</span>
            </h1>
          </div>

          {/* Subheading */}
          <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto text-pretty">
            Plots in fast-developing locations with verified titles and flexible payment options.
          </p>

          {/* Trust Line */}
          <p className="text-sm md:text-base text-green-300 font-semibold">
            ✓ Trusted by smart investors who don&apos;t wait
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-8">
            <Link href={whatsappLink} target="_blank" rel="noopener noreferrer">
              <Button
                size="lg"
                className="bg-green-500 hover:bg-green-600 text-black font-bold text-lg px-8 rounded-lg transition-all duration-300 hover:scale-105"
              >
                <MessageCircle className="mr-2 h-5 w-5" />
                Chat on WhatsApp
              </Button>
            </Link>
            <Button
              size="lg"
              variant="outline"
              className="border-green-500 text-green-400 hover:bg-green-500/10 font-bold text-lg px-8 rounded-lg"
            >
              <Eye className="mr-2 h-5 w-5" />
              View Available Lands
            </Button>
            <Link href="https://instagram.com/official_greenfieldmegavision" target="_blank" rel="noopener noreferrer">
              <Button
                size="lg"
                variant="outline"
                className="border-blue-500 text-blue-400 hover:bg-blue-500/10 font-bold text-lg px-8 rounded-lg"
              >
                <Instagram className="mr-2 h-5 w-5" />
                Instagram
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10 animate-bounce">
        <div className="flex flex-col items-center text-green-400">
          <p className="text-sm font-semibold mb-2">Scroll to explore</p>
          <svg
            className="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M19 14l-7 7m0 0l-7-7m7 7V3"
            />
          </svg>
        </div>
      </div>
    </section>
  )
}
