import { Navbar } from '@/components/navbar';
import { Footer } from '@/components/footer';
import { FloatingCTA } from '@/components/floating-cta';
import Link from 'next/link';

export default function Plots() {
  return (
    <>
      <Navbar />
      <main className="overflow-hidden">
        {/* Hero Section */}
        <section className="pt-24 pb-16 px-6">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">Available Investment Plots</h1>
            <p className="text-lg text-muted max-w-2xl mx-auto">
              Choose from our premium land parcels with flexible payment options. All plots have verified titles and infrastructure.
            </p>
          </div>
        </section>

        {/* Plot Options */}
        <section className="py-16 px-6">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold mb-4 text-foreground text-center">Investment Opportunities</h2>
            <p className="text-center text-muted mb-12 max-w-2xl mx-auto">
              Choose your investment tier and secure guaranteed returns. Each plot comes with verified titles and comprehensive legal documentation.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                { size: '500 sqm', price: '₦1.5M', projected: '₦2.3M', appreciation: '153%', tier: 'Starter' },
                { size: '750 sqm', price: '₦2.25M', projected: '₦3.6M', appreciation: '160%', tier: 'Growth', featured: true },
                { size: '1000 sqm', price: '₦3M', projected: '₦4.9M', appreciation: '163%', tier: 'Premium' },
              ].map((plot, idx) => (
                <div key={idx} className={`cta-card ${plot.featured ? 'md:scale-105 border-primary' : ''}`}>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-bold text-foreground">{plot.size}</h3>
                    <span className="text-xs font-semibold px-3 py-1 rounded-full bg-primary/10 text-primary">{plot.tier}</span>
                  </div>
                  <div className="space-y-4 mb-6">
                    <div>
                      <p className="text-xs text-muted mb-1">Investment Amount</p>
                      <p className="text-2xl font-bold text-foreground">{plot.price}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted mb-1">Projected Value (24 months)</p>
                      <p className="text-xl font-bold text-primary">{plot.projected}</p>
                    </div>
                    <div className="bg-primary/5 rounded-lg p-4 border border-primary/20">
                      <p className="text-xs text-muted mb-1">Expected Appreciation</p>
                      <p className="text-2xl font-bold gradient-text">{plot.appreciation}</p>
                    </div>
                  </div>
                  <a
                    href={`https://wa.me/2348099955884?text=I'm%20interested%20in%20reserving%20the%20${plot.size}%20plot%20(${plot.tier}%20tier)%20at%20Greenfield%20Megavision`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full block px-4 py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:bg-accent transition-all duration-300 text-center hover:shadow-lg hover:shadow-primary/40 active:scale-95"
                  >
                    Reserve Now on WhatsApp
                  </a>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Estate Features */}
        <section className="py-16 px-6">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-foreground text-center">Premium Estate Features</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                { title: 'Modern Infrastructure', desc: 'Well-designed roads and utilities' },
                { title: '24/7 Security', desc: 'Professional security and surveillance' },
                { title: 'Green Spaces', desc: 'Landscaped parks and recreation areas' },
                { title: 'Medical Facilities', desc: 'On-site clinic and health services' },
                { title: 'Shopping Center', desc: 'Commercial area for businesses' },
                { title: 'Sports & Recreation', desc: 'Courts and recreational facilities' },
              ].map((feature, idx) => (
                <div key={idx} className="border border-border bg-card rounded-lg p-8 text-center">
                  <h3 className="text-lg font-bold text-foreground mb-2">{feature.title}</h3>
                  <p className="text-muted text-sm">{feature.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Availability Info */}
        <section className="py-16 px-6 bg-secondary/5">
          <div className="max-w-6xl mx-auto">
            <div className="border border-border bg-card rounded-lg p-12">
              <div className="grid grid-cols-3 gap-8 text-center mb-8">
                <div>
                  <p className="text-4xl font-bold text-primary mb-2">150+</p>
                  <p className="text-muted text-sm">Plots Remaining</p>
                </div>
                <div>
                  <p className="text-3xl font-bold text-primary mb-2">3,500</p>
                  <p className="text-muted text-sm">Total Sq Meters</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-primary mb-2">URGENT</p>
                  <p className="text-muted text-sm">Reducing Availability</p>
                </div>
              </div>
              <p className="text-center text-muted mb-8">
                Plots are allocating quickly as investors recognize the value. Secure your preferred plot size and location today.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a
                  href="https://wa.me/2348099955884?text=I%20want%20to%20reserve%20a%20plot%20at%20Greenfield%20Megavision"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-8 py-3 bg-primary text-primary-foreground rounded font-semibold hover:bg-accent transition-colors"
                >
                  Reserve Your Plot
                </a>
                <Link href="/contact" className="px-8 py-3 border-2 border-primary text-primary rounded font-semibold hover:bg-primary hover:text-primary-foreground transition-colors">
                  Ask Questions
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <FloatingCTA />
    </>
  );
}
