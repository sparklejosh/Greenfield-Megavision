'use client';

import { MessageCircle, Mail, Phone, ArrowRight } from 'lucide-react';

export function FinalCTA() {
  const contactOptions = [
    {
      icon: MessageCircle,
      title: 'WhatsApp Consultation',
      description: 'Chat instantly with our investment advisor',
      action: 'Start Chat',
      onClick: () => {
        window.open(
          'https://wa.me/2348099955884?text=Hello%20Greenfield%20Megavision,%20I%27d%20like%20to%20schedule%20a%20consultation%20about%20land%20investment%20opportunities.',
          '_blank'
        );
      },
    },
    {
      icon: Mail,
      title: 'Email Inquiry',
      description: 'Send detailed questions and documentation',
      action: 'Send Email',
      onClick: () => {
        window.location.href = 'mailto:contact@greenfieldmegavision.com?subject=Land%20Investment%20Inquiry';
      },
    },
    {
      icon: Phone,
      title: 'Phone Call',
      description: 'Speak directly with our team',
      action: 'Call Now',
      onClick: () => {
        window.location.href = 'tel:+2348099955884';
      },
    },
  ];

  return (
    <section className="py-20 md:py-32 bg-gradient-to-b from-primary/5 to-white">
      <div className="max-w-7xl mx-auto px-6">
        {/* Main CTA */}
        <div className="bg-gradient-to-r from-primary via-accent to-primary rounded-2xl p-8 md:p-16 mb-16 text-white text-center animate-slide-up">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">Ready to Build Wealth?</h2>
          <p className="text-lg text-white/90 max-w-2xl mx-auto mb-8">
            Join 500+ smart investors who are securing their financial future through strategic land investment
          </p>
          <p className="text-white/80 mb-8">
            Limited plots available. High-demand locations filling up fast.
          </p>
          <button
            onClick={() => {
              window.open(
                'https://wa.me/2348099955884?text=Hello%20Greenfield%20Megavision,%20I%27m%20ready%20to%20start%20my%20land%20investment%20journey.',
                '_blank'
              );
            }}
            className="inline-flex items-center gap-2 bg-white text-primary px-8 py-4 rounded-lg font-bold hover:bg-white/90 transition-all active:scale-95"
          >
            Start Your Journey Now
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>

        {/* Contact Options */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16 animate-fade-in">
          {contactOptions.map((option, index) => {
            const Icon = option.icon;
            return (
              <button
                key={index}
                onClick={option.onClick}
                className="card-premium-lg text-left group hover:shadow-xl transition-all"
              >
                <div className="flex items-start gap-4 mb-6">
                  <div className="p-3 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors">
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-foreground mb-1">{option.title}</h3>
                    <p className="text-sm text-muted">{option.description}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 pt-4 border-t border-border text-primary font-semibold">
                  {option.action}
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </button>
            );
          })}
        </div>

        {/* FAQ Preview */}
        <div className="bg-white rounded-2xl p-8 md:p-12 border border-border animate-fade-in">
          <h3 className="text-2xl font-bold mb-8 text-foreground">Common Questions</h3>
          <div className="space-y-6">
            {[
              {
                q: 'How much does it take to start investing?',
                a: 'You can start with our Starter tier at ₦1,500,000, or choose larger plots based on your investment capacity.',
              },
              {
                q: 'Is the title truly verified?',
                a: 'Yes. Every plot comes with government-registered titles, surveyed boundaries, and complete legal documentation.',
              },
              {
                q: 'When can I sell my plot?',
                a: 'You have full ownership and can sell anytime. High resale demand means quick transactions at appreciated prices.',
              },
              {
                q: 'What are the hidden costs?',
                a: 'There are no hidden costs. The investment price is all-inclusive with zero additional charges.',
              },
            ].map((faq, index) => (
              <div key={index} className="border-b border-border last:border-0 pb-6 last:pb-0">
                <h4 className="font-bold text-foreground mb-2">{faq.q}</h4>
                <p className="text-muted">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
