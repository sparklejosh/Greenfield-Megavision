'use client';

import { Check } from 'lucide-react';

export function PlotsMenu() {
  const plots = [
    {
      tier: 'Starter',
      size: '500 sqm',
      price: '₦1,500,000',
      projectedValue: '₦2,340,000',
      roi: '56%',
      paymentPlans: ['1 payment', '3 installments'],
      features: [
        'Verified Title',
        'Gated Community Access',
        'Security 24/7',
        'Basic Infrastructure',
      ],
    },
    {
      tier: 'Growth',
      size: '1000 sqm',
      price: '₦2,800,000',
      projectedValue: '₦4,368,000',
      roi: '56%',
      paymentPlans: ['1 payment', '6 installments', '12 installments'],
      features: [
        'Verified Title',
        'Premium Location',
        'Gated Community Access',
        'Full Infrastructure',
        'Free Legal Support',
      ],
      popular: true,
    },
    {
      tier: 'Premium',
      size: '2000 sqm',
      price: '₦5,200,000',
      projectedValue: '₦8,112,000',
      roi: '56%',
      paymentPlans: ['1 payment', '6 installments', '12 installments', '18 installments'],
      features: [
        'Verified Title',
        'Prime Location',
        'Gated Community Access',
        'Full Infrastructure',
        'Free Legal Support',
        'Investment Portfolio Management',
      ],
    },
  ];

  const handleSelectPlot = (tier: string) => {
    window.open(
      `https://wa.me/2348099955884?text=Hello%20Greenfield%20Megavision,%20I'm%20interested%20in%20the%20${tier}%20plot%20offering.`,
      '_blank'
    );
  };

  return (
    <section id="plots" className="py-20 md:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="section-heading mb-4">Investment Opportunities</h2>
          <p className="section-subheading mx-auto">
            Choose the plot size that matches your investment goals
          </p>
        </div>

        {/* Pricing Tiers */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16 animate-slide-up">
          {plots.map((plot, index) => (
            <div
              key={index}
              className={`relative rounded-2xl transition-all duration-300 overflow-hidden ${
                plot.popular
                  ? 'ring-2 ring-primary shadow-2xl md:scale-105'
                  : 'border border-border'
              } bg-white`}
            >
              {/* Popular Badge */}
              {plot.popular && (
                <div className="absolute top-0 right-0 bg-gradient-to-r from-primary to-accent text-white px-4 py-1 text-xs font-bold rounded-bl-lg">
                  MOST POPULAR
                </div>
              )}

              <div className="p-8">
                {/* Tier Name */}
                <h3 className="text-2xl font-bold text-foreground mb-2">{plot.tier}</h3>
                <p className="text-muted text-sm mb-6">Perfect for investors seeking {plot.tier.toLowerCase()} returns</p>

                {/* Size */}
                <div className="mb-6 pb-6 border-b border-border">
                  <p className="text-muted text-sm mb-1">Plot Size</p>
                  <p className="text-3xl font-bold text-foreground">{plot.size}</p>
                </div>

                {/* Pricing */}
                <div className="mb-6 space-y-2">
                  <div className="flex justify-between items-baseline">
                    <span className="text-muted">Investment</span>
                    <span className="text-2xl font-bold text-primary">{plot.price}</span>
                  </div>
                  <div className="flex justify-between items-baseline pt-2 border-t border-border">
                    <span className="text-muted">Projected Value (18mo)</span>
                    <span className="text-xl font-bold text-accent">{plot.projectedValue}</span>
                  </div>
                </div>

                {/* ROI Highlight */}
                <div className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-lg p-4 mb-6 border border-primary/20">
                  <p className="text-muted text-xs mb-1">Expected ROI</p>
                  <p className="text-3xl font-bold text-primary">{plot.roi}</p>
                </div>

                {/* Payment Plans */}
                <div className="mb-6">
                  <p className="text-muted text-sm mb-3 font-semibold">Payment Plans Available</p>
                  <div className="flex flex-wrap gap-2">
                    {plot.paymentPlans.map((plan, planIndex) => (
                      <span
                        key={planIndex}
                        className="px-3 py-1 bg-primary/10 text-primary text-xs rounded-full border border-primary/20"
                      >
                        {plan}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Features */}
                <div className="mb-8 space-y-2">
                  {plot.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-primary" />
                      <span className="text-sm text-foreground">{feature}</span>
                    </div>
                  ))}
                </div>

                {/* CTA */}
                <button
                  onClick={() => handleSelectPlot(plot.tier)}
                  className={`w-full py-3 rounded-lg font-semibold transition-all duration-200 ${
                    plot.popular
                      ? 'btn-primary'
                      : 'border-2 border-primary text-primary hover:bg-primary hover:text-white'
                  }`}
                >
                  Select {plot.tier}
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Comparison Table */}
        <div className="bg-gradient-to-br from-primary/5 to-accent/5 rounded-2xl overflow-hidden border border-border animate-fade-in">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-primary/10 border-b border-primary/20">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-bold text-foreground">Feature</th>
                  <th className="px-6 py-4 text-center text-sm font-bold text-foreground">Starter</th>
                  <th className="px-6 py-4 text-center text-sm font-bold text-foreground">Growth</th>
                  <th className="px-6 py-4 text-center text-sm font-bold text-foreground">Premium</th>
                </tr>
              </thead>
              <tbody>
                {[
                  { feature: 'Verified Legal Title', starter: true, growth: true, premium: true },
                  { feature: 'Location Quality', starter: '✓', growth: '✓✓', premium: '✓✓✓' },
                  { feature: 'Payment Flexibility', starter: '2', growth: '3', premium: '4' },
                  { feature: 'Legal Support', starter: '—', growth: '✓', premium: '✓' },
                  { feature: 'Portfolio Management', starter: '—', growth: '—', premium: '✓' },
                ].map((row, index) => (
                  <tr key={index} className="border-b border-border hover:bg-white/50">
                    <td className="px-6 py-4 text-sm text-foreground">{row.feature}</td>
                    <td className="px-6 py-4 text-center text-sm text-primary">
                      {typeof row.starter === 'boolean' ? (row.starter ? '✓' : '—') : row.starter}
                    </td>
                    <td className="px-6 py-4 text-center text-sm text-primary">
                      {typeof row.growth === 'boolean' ? (row.growth ? '✓' : '—') : row.growth}
                    </td>
                    <td className="px-6 py-4 text-center text-sm text-primary">
                      {typeof row.premium === 'boolean' ? (row.premium ? '✓' : '—') : row.premium}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
}
