import { Navbar } from '@/components/navbar';
import { Footer } from '@/components/footer';
import { FloatingCTA } from '@/components/floating-cta';
import Link from 'next/link';

export default function PaymentPlans() {
  return (
    <>
      <Navbar />
      <main className="overflow-hidden">
        {/* Hero Section */}
        <section className="pt-24 pb-16 px-6">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">Flexible Payment Plans</h1>
            <p className="text-lg text-muted max-w-2xl mx-auto">
              Choose a payment schedule that works for your budget. All plans include verified titles and full legal protection.
            </p>
          </div>
        </section>

        {/* Payment Options */}
        <section className="py-16 px-6 bg-secondary/5">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-foreground text-center">Our Payment Options</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  title: 'Immediate Payment',
                  desc: 'Pay the full amount upfront',
                  benefits: ['Instant ownership', 'No interest', 'Guaranteed allocation', 'Priority location'],
                  cta: 'Best for Investors',
                },
                {
                  title: '3-Month Plan',
                  desc: 'Three equal installments',
                  benefits: ['Flexible schedule', 'No hidden fees', '33% down payment', 'Clear milestones'],
                  cta: 'Most Popular',
                },
                {
                  title: '6-Month Plan',
                  desc: 'Six equal installments',
                  benefits: ['Manageable payments', 'Detailed timeline', '20% down payment', 'Full support'],
                  cta: 'Budget-Friendly',
                },
              ].map((plan, idx) => (
                <div key={idx} className={`border rounded-lg p-8 flex flex-col ${idx === 1 ? 'border-primary bg-card ring-2 ring-primary/20' : 'border-border bg-card'}`}>
                  {idx === 1 && <span className="text-primary font-semibold text-sm mb-4">RECOMMENDED</span>}
                  <h3 className="text-2xl font-bold text-foreground mb-2">{plan.title}</h3>
                  <p className="text-muted mb-6">{plan.desc}</p>
                  <ul className="space-y-3 mb-8 flex-1">
                    {plan.benefits.map((benefit, i) => (
                      <li key={i} className="flex items-center text-muted text-sm">
                        <span className="w-2 h-2 bg-primary rounded-full mr-3" />
                        {benefit}
                      </li>
                    ))}
                  </ul>
                  <button className="w-full px-4 py-3 bg-primary text-primary-foreground rounded font-semibold hover:bg-accent transition-colors">
                    Choose {plan.cta}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Payment Timeline Example */}
        <section className="py-16 px-6">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-foreground text-center">Payment Timeline Example</h2>
            <p className="text-muted text-center mb-12 max-w-2xl mx-auto">
              Here&apos;s how payment works for a ₦2.25M (750 sqm) plot using the 3-month plan:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                { month: 'Month 1', amount: '₦750K', status: 'Initial Payment', desc: 'Down payment (33%)' },
                { month: 'Month 2', amount: '₦750K', status: 'Second Payment', desc: 'Equal installment' },
                { month: 'Month 3', amount: '₦750K', status: 'Final Payment', desc: 'Complete ownership' },
              ].map((payment, idx) => (
                <div key={idx} className="border border-border bg-card rounded-lg p-8">
                  <p className="text-primary font-bold text-sm mb-2">{payment.month}</p>
                  <p className="text-3xl font-bold text-foreground mb-2">{payment.amount}</p>
                  <p className="font-semibold text-foreground mb-2">{payment.status}</p>
                  <p className="text-muted text-sm">{payment.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* FAQs */}
        <section className="py-16 px-6 bg-secondary/5">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-foreground text-center">Frequently Asked Questions</h2>
            <div className="space-y-6">
              {[
                { q: 'Is there interest on installment plans?', a: 'No. All our payment plans have zero interest. You pay only for the land value.' },
                { q: 'Can I switch payment plans later?', a: 'Yes. Contact us within 30 days of your initial agreement to modify your plan.' },
                { q: 'What happens if I miss a payment?', a: 'We provide a 30-day grace period. Contact us immediately to reschedule.' },
                { q: 'When do I get my legal documents?', a: 'Upon final payment, you receive all verified title documents and legal registration papers.' },
                { q: 'Are there any hidden fees?', a: 'Absolutely not. All costs are clearly stated upfront with no hidden charges.' },
              ].map((faq, idx) => (
                <div key={idx} className="border border-border bg-card rounded-lg p-6">
                  <h3 className="font-bold text-foreground mb-2">{faq.q}</h3>
                  <p className="text-muted text-sm">{faq.a}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-16 px-6">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6 text-foreground">Ready to Get Started?</h2>
            <p className="text-muted mb-8 max-w-2xl mx-auto">
              Choose your preferred payment plan and secure your investment today.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="https://wa.me/2348099955884?text=I%20want%20to%20discuss%20payment%20plans"
                target="_blank"
                rel="noopener noreferrer"
                className="px-8 py-3 bg-primary text-primary-foreground rounded font-semibold hover:bg-accent transition-colors"
              >
                Chat with Us
              </a>
              <Link href="/contact" className="px-8 py-3 border-2 border-primary text-primary rounded font-semibold hover:bg-primary hover:text-primary-foreground transition-colors">
                Get More Details
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <FloatingCTA />
    </>
  );
}
