'use client'

import { Card } from '@/components/ui/card'
import {
  Home,
  Shield,
  ShoppingCart,
  Heart,
  Zap,
  Zap as Wifi,
} from 'lucide-react'

export default function EstateFeatures() {
  const features = [
    {
      icon: Home,
      title: 'Gate House',
      description: 'Premium entrance with security checkpoint',
    },
    {
      icon: Shield,
      title: 'Security Office',
      description: '24/7 armed security personnel on duty',
    },
    {
      icon: ShoppingCart,
      title: 'Shopping Complex',
      description: 'Modern retail shops and restaurants',
    },
    {
      icon: Heart,
      title: 'Clinic',
      description: 'On-site healthcare facility',
    },
    {
      icon: Zap,
      title: 'Full Electrification',
      description: 'Solar + grid power backup systems',
    },
    {
      icon: Wifi,
      title: 'Recreation Center',
      description: 'Sports facilities and community events',
    },
  ]

  return (
    <section className="py-20 md:py-32 bg-gradient-to-b from-green-950/10 to-transparent">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Estate <span className="text-green-400">Features & Amenities</span>
          </h2>
          <p className="text-gray-400 text-lg">
            Greenfield Megavision is not just land—it&apos;s a complete community
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {features.map((feature, index) => {
            const Icon = feature.icon
            return (
              <Card
                key={index}
                className="bg-gradient-to-br from-green-500/5 via-transparent to-transparent border border-green-500/20 hover:border-green-500/50 hover:scale-105 transition-all duration-300 p-8 group"
              >
                <div className="space-y-4">
                  {/* Icon */}
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-green-500/20 rounded-lg group-hover:bg-green-500/30 transition-colors">
                    <Icon className="h-8 w-8 text-green-400" />
                  </div>

                  {/* Content */}
                  <div>
                    <h3 className="text-lg font-bold text-white mb-2">
                      {feature.title}
                    </h3>
                    <p className="text-gray-400 text-sm">
                      {feature.description}
                    </p>
                  </div>
                </div>
              </Card>
            )
          })}
        </div>

        {/* Additional Info */}
        <Card className="bg-gradient-to-r from-green-500/10 via-transparent to-green-500/5 border border-green-500/30 p-8 text-center">
          <p className="text-white text-lg mb-2">
            Premium infrastructure designed for <span className="text-green-400 font-bold">investors and residents</span>
          </p>
          <p className="text-gray-400">
            Every detail has been planned for value, security, and long-term appreciation
          </p>
        </Card>
      </div>
    </section>
  )
}
