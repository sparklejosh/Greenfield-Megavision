'use client'

import { Card } from '@/components/ui/card'
import { Zap, Shield, TrendingUp, Home, Lock, Zap as Flash } from 'lucide-react'

export default function WhyInvestSection() {
  const reasons = [
    {
      icon: Zap,
      title: 'Fast-Developing Locations',
      description: 'Strategic areas with planned infrastructure, schools, hospitals, and commercial centers nearby.',
    },
    {
      icon: Shield,
      title: 'Verified Land Titles',
      description: 'All plots come with comprehensive title verification and legal documentation you can trust.',
    },
    {
      icon: TrendingUp,
      title: 'Flexible Payment Plans',
      description: 'Pay in installments over 12-24 months with zero interest and no hidden charges.',
    },
    {
      icon: Home,
      title: 'High Appreciation Potential',
      description: 'Watch your investment grow 2-3x in 18-24 months as the area develops.',
    },
    {
      icon: Lock,
      title: 'Secure Estates',
      description: '24/7 security, gated communities, and modern infrastructure from day one.',
    },
    {
      icon: Flash,
      title: 'Instant Liquidity',
      description: 'Easily resell your plots at premium prices. High demand means quick sales.',
    },
  ]

  return (
    <section className="py-20 md:py-32 bg-gradient-to-b from-transparent to-green-950/10">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Why Smart Investors<br />
            <span className="text-green-400">Don&apos;t Delay</span>
          </h2>
          <p className="text-gray-400 text-lg">
            Six reasons to act now, not later
          </p>
        </div>

        {/* Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reasons.map((reason, index) => {
            const Icon = reason.icon
            return (
              <Card
                key={index}
                className="bg-gradient-to-br from-green-500/5 via-transparent to-transparent border border-green-500/20 hover:border-green-500/50 hover:bg-green-500/10 transition-all duration-300 p-6 group"
              >
                <div className="space-y-4">
                  {/* Icon */}
                  <div className="inline-flex items-center justify-center w-14 h-14 bg-green-500/20 rounded-lg group-hover:bg-green-500/30 transition-colors">
                    <Icon className="h-7 w-7 text-green-400" />
                  </div>

                  {/* Content */}
                  <div>
                    <h3 className="text-lg font-bold text-white mb-2">
                      {reason.title}
                    </h3>
                    <p className="text-gray-400 text-sm leading-relaxed">
                      {reason.description}
                    </p>
                  </div>
                </div>
              </Card>
            )
          })}
        </div>

        {/* Bottom CTA */}
        <div className="mt-16 text-center">
          <p className="text-gray-400 text-base md:text-lg">
            Every month you wait, prices increase.{' '}
            <span className="text-green-400 font-bold">The best time to buy is today.</span>
          </p>
        </div>
      </div>
    </section>
  )
}
