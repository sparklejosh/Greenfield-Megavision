'use client'

import Link from 'next/link'
import { MessageCircle } from 'lucide-react'

export default function FloatingWhatsApp() {
  const whatsappLink = "https://wa.me/2348099955884?text=Hi%20Greenfield%20Megavision!%20I'm%20interested%20in%20learning%20more%20about%20your%20land%20plots."

  return (
    <Link
      href={whatsappLink}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-8 right-8 z-50 group"
    >
      <div className="relative">
        {/* Glow effect */}
        <div className="absolute inset-0 bg-green-500 rounded-full blur-lg opacity-75 group-hover:opacity-100 transition-opacity duration-300 animate-pulse"></div>

        {/* Button */}
        <div className="relative bg-green-500 hover:bg-green-600 text-white rounded-full p-4 shadow-2xl transition-all duration-300 group-hover:scale-110 flex items-center justify-center cursor-pointer">
          <MessageCircle className="h-6 w-6" />
        </div>

        {/* Label */}
        <div className="absolute bottom-16 right-0 bg-green-500 text-black font-semibold text-sm px-4 py-2 rounded-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none shadow-lg">
          Chat Now
        </div>
      </div>
    </Link>
  )
}
