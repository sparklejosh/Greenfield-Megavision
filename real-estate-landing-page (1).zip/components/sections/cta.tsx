'use client'

import { Button } from '@/components/ui/button'
import { MessageCircle, Facebook, Instagram } from 'lucide-react'
import Link from 'next/link'

export default function CTASection() {
  const whatsappLink = "https://wa.me/2348099955884?text=Hi%20Greenfield%20Megavision!%20I'm%20interested%20in%20learning%20more%20about%20your%20land%20plots."

  return (
    <section className="py-20 md:py-32 bg-gradient-to-b from-transparent to-green-950/30 relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute inset-0 bg-gradient-to-r from-green-900/20 via-transparent to-transparent pointer-events-none"></div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Main CTA Box */}
        <div className="bg-gradient-to-br from-green-500/10 via-transparent to-green-500/5 border border-green-500/30 rounded-2xl p-12 md:p-16 text-center space-y-8">
          <h2 className="text-4xl md:text-5xl font-bold text-white text-balance">
            Don&apos;t Miss This One Too
          </h2>

          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            <span className="text-green-400 font-semibold">
              Get price, location, and payment plan instantly
            </span>
            <br />
            <span className="text-gray-400 text-lg">
              Our agents are ready to help you make the best investment decision.
            </span>
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
            <Link href={whatsappLink} target="_blank" rel="noopener noreferrer">
              <Button
                size="lg"
                className="bg-green-500 hover:bg-green-600 text-black font-bold text-lg px-8 rounded-lg transition-all duration-300 hover:scale-105 w-full sm:w-auto"
              >
                <MessageCircle className="mr-2 h-5 w-5" />
                Chat on WhatsApp
              </Button>
            </Link>
          </div>

          {/* Social Links */}
          <div className="pt-8 border-t border-green-500/20">
            <p className="text-gray-400 text-sm mb-4">
              Connect with us on social media
            </p>
            <div className="flex justify-center gap-4">
              <Link
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button
                  variant="outline"
                  size="lg"
                  className="border-blue-500 text-blue-400 hover:bg-blue-500/10 rounded-lg"
                >
                  <Facebook className="h-5 w-5" />
                </Button>
              </Link>
              <Link
                href="https://instagram.com/official_greenfieldmegavision"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button
                  variant="outline"
                  size="lg"
                  className="border-pink-500 text-pink-400 hover:bg-pink-500/10 rounded-lg"
                >
                  <Instagram className="h-5 w-5" />
                </Button>
              </Link>
            </div>
          </div>

          {/* Trust Statement */}
          <p className="text-gray-500 text-sm pt-4">
            ✓ Verified land titles | ✓ Secure payment | ✓ Legal support | ✓ Investment protection
          </p>
        </div>
      </div>
    </section>
  )
}
