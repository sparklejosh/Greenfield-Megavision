'use client'

import { Card } from '@/components/ui/card'
import { AlertCircle, Clock } from 'lucide-react'

export default function UrgencySection() {
  return (
    <section className="py-20 md:py-32 bg-gradient-to-b from-green-950/20 to-transparent relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-green-500/5 rounded-full blur-3xl -z-10"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-green-500/5 rounded-full blur-3xl -z-10"></div>

      <div className="container mx-auto px-4">
        <Card className="bg-gradient-to-r from-red-950/30 via-transparent to-green-950/30 border border-red-500/30 p-8 md:p-12 relative overflow-hidden">
          {/* Content */}
          <div className="relative z-10 space-y-6">
            {/* Header */}
            <div className="flex items-start gap-4">
              <div className="inline-flex items-center justify-center w-12 h-12 bg-red-500/20 rounded-lg flex-shrink-0">
                <AlertCircle className="h-6 w-6 text-red-400" />
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-white">
                Prices Don&apos;t Stay the Same
              </h2>
            </div>

            {/* Main Message */}
            <p className="text-lg text-gray-300 max-w-3xl">
              The last set of buyers secured plots at significantly lower prices. Current prices reflect market demand—and{' '}
              <span className="text-red-400 font-bold">they will increase again.</span>
            </p>

            {/* Stats */}
            <div className="grid md:grid-cols-3 gap-4 pt-4">
              <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4">
                <p className="text-sm text-gray-400 mb-1">Last Price Increase</p>
                <p className="text-2xl font-bold text-green-400">25-30%</p>
              </div>
              <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4">
                <p className="text-sm text-gray-400 mb-1">Months Between Increases</p>
                <p className="text-2xl font-bold text-green-400">3-4 months</p>
              </div>
              <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4">
                <p className="text-sm text-gray-400 mb-1">Next Review</p>
                <p className="text-2xl font-bold text-red-400">Soon</p>
              </div>
            </div>

            {/* Countdown Message */}
            <div className="flex items-center gap-3 bg-red-500/10 border border-red-500/20 rounded-lg p-4">
              <Clock className="h-5 w-5 text-red-400 flex-shrink-0" />
              <p className="text-gray-300">
                <span className="font-bold text-red-400">Next review coming soon.</span> Lock in your price today before it increases.
              </p>
            </div>
          </div>

          {/* Corner Accent */}
          <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-bl from-red-500/10 to-transparent rounded-bl-3xl pointer-events-none"></div>
        </Card>
      </div>
    </section>
  )
}
