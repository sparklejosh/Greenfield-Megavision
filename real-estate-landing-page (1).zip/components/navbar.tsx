'use client';

import Image from 'next/image';
import Link from 'next/link';
import { ThemeToggle } from './theme-toggle';

export function Navbar() {
  const handleWhatsappClick = () => {
    window.open(
      'https://wa.me/2348099955884?text=Hello%20Greenfield%20Megavision,%20I%27m%20interested%20in%20your%20land%20investment%20opportunity.',
      '_blank'
    );
  };

  return (
    <nav className="sticky top-0 z-50 bg-card/95 backdrop-blur-md border-b border-border">
      <div className="max-w-7xl mx-auto px-6 py-3 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 group flex-shrink-0">
          <div className="w-8 h-8 relative">
            <Image
              src="/logo.png"
              alt="Greenfield Megavision"
              fill
              className="object-contain"
            />
          </div>
          <div className="hidden sm:flex flex-col">
            <span className="font-bold text-xs text-foreground group-hover:text-primary transition-colors leading-none">
              GREENFIELD
            </span>
            <span className="text-[10px] text-muted leading-none">MEGAVISION</span>
          </div>
        </Link>

        {/* Navigation Links */}
        <div className="hidden lg:flex items-center gap-6">
          <Link href="/about" className="text-xs font-medium text-muted hover:text-foreground transition-colors">
            About
          </Link>
          <Link href="/investment" className="text-xs font-medium text-muted hover:text-foreground transition-colors">
            Investment
          </Link>
          <Link href="/plots" className="text-xs font-medium text-muted hover:text-foreground transition-colors">
            Plots
          </Link>
          <Link href="/payment-plans" className="text-xs font-medium text-muted hover:text-foreground transition-colors">
            Payment Plans
          </Link>
          <Link href="/contact" className="text-xs font-medium text-muted hover:text-foreground transition-colors">
            Contact
          </Link>
        </div>

        {/* Theme Toggle & CTA */}
        <div className="flex items-center gap-2 flex-shrink-0">
          <ThemeToggle />
          <button
            onClick={handleWhatsappClick}
            className="px-4 py-2 bg-primary text-primary-foreground text-xs font-semibold rounded hover:bg-accent transition-colors"
          >
            WhatsApp
          </button>
        </div>
      </div>
    </nav>
  );
}
