'use client';

import { MessageCircle } from 'lucide-react';

export function FloatingCTA() {
  const handleClick = () => {
    window.open(
      'https://wa.me/2348099955884?text=Hello%20Greenfield%20Megavision,%20I%27d%20like%20to%20learn%20more%20about%20your%20land%20investment%20opportunities.',
      '_blank'
    );
  };

  return (
    <button
      onClick={handleClick}
      className="fixed bottom-6 right-6 z-40 bg-primary text-white p-4 rounded-full shadow-lg hover:shadow-2xl hover:scale-110 transition-all duration-300 animate-glow-pulse"
      aria-label="Contact via WhatsApp"
    >
      <MessageCircle className="w-6 h-6" />
    </button>
  );
}
