'use client';

import { Lock, Award, FileCheck, Users } from 'lucide-react';

export function TrustCredentials() {
  const credentials = [
    {
      icon: Lock,
      title: 'Fully Registered Properties',
      description: 'All plots registered with the Land Registry with verified titles and government certification',
      stats: '100% Verified',
    },
    {
      icon: Award,
      title: 'Professional Certifications',
      description: 'Licensed estate developers with 10+ years of successful track record in land investment',
      stats: '10+ Years',
    },
    {
      icon: FileCheck,
      title: 'Legal Compliance',
      description: 'Full compliance with Nigerian real estate laws, tax regulations, and investment guidelines',
      stats: 'Audit Compliant',
    },
    {
      icon: Users,
      title: 'Investor Protection',
      description: '500+ successful investors with documented returns and verified testimonials',
      stats: '98% Satisfaction',
    },
  ];

  const documents = [
    'Certificate of Occupancy',
    'Land Registry Documents',
    'Deed of Assignment',
    'Tax Clearance Certificate',
    'Government Approval',
    'Surveyor Report',
  ];

  return (
    <section id="trust" className="py-20 md:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="section-heading mb-4">Trust, Verified & Compliant</h2>
          <p className="section-subheading mx-auto">
            Your investment is protected by legal documentation, professional management, and transparent operations
          </p>
        </div>

        {/* Credentials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16 animate-slide-up">
          {credentials.map((credential, index) => {
            const Icon = credential.icon;
            return (
              <div key={index} className="card-premium-lg">
                <div className="flex items-start gap-6 mb-6">
                  <div className="p-4 bg-primary/10 rounded-lg">
                    <Icon className="w-8 h-8 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-foreground mb-2">{credential.title}</h3>
                    <p className="text-muted text-sm">{credential.description}</p>
                  </div>
                </div>
                <div className="flex items-center justify-between pt-4 border-t border-border">
                  <span className="text-muted text-sm">Status</span>
                  <span className="inline-flex items-center gap-2 px-3 py-1 bg-primary/10 text-primary rounded-full text-sm font-semibold border border-primary/20">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    {credential.stats}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Documents Available */}
        <div className="bg-gradient-to-br from-primary/5 via-white to-accent/5 rounded-2xl p-8 md:p-12 border border-border mb-16 animate-fade-in">
          <h3 className="text-2xl font-bold mb-8 text-foreground">Legal Documentation</h3>
          <p className="text-muted mb-8">
            Every investor receives complete legal documentation ensuring transparency and security:
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {documents.map((doc, index) => (
              <div
                key={index}
                className="flex items-center gap-3 p-4 bg-white rounded-lg border border-border hover:border-primary/30 transition-colors"
              >
                <FileCheck className="w-5 h-5 text-primary flex-shrink-0" />
                <span className="text-foreground font-medium">{doc}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Investment Guarantee */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-slide-up">
          <div className="card-premium-lg">
            <h3 className="text-xl font-bold mb-4 text-foreground">Our Investment Guarantee</h3>
            <div className="space-y-4">
              <p className="text-muted">
                We stand behind our investments with:
              </p>
              <ul className="space-y-3">
                <li className="flex gap-3">
                  <span className="text-primary font-bold">✓</span>
                  <span className="text-foreground">Verified legal titles with government certification</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-primary font-bold">✓</span>
                  <span className="text-foreground">Clear ownership documentation with no disputes</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-primary font-bold">✓</span>
                  <span className="text-foreground">Transparent pricing with zero hidden costs</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-primary font-bold">✓</span>
                  <span className="text-foreground">Professional legal support throughout process</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-primary font-bold">✓</span>
                  <span className="text-foreground">Secure estate management and development</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="card-premium-lg">
            <h3 className="text-xl font-bold mb-4 text-foreground">Investor Rights Protected</h3>
            <div className="space-y-4">
              <p className="text-muted">
                Your rights as an investor are fully protected:
              </p>
              <ul className="space-y-3">
                <li className="flex gap-3">
                  <span className="text-primary font-bold">✓</span>
                  <span className="text-foreground">Full legal ownership with certificate of title</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-primary font-bold">✓</span>
                  <span className="text-foreground">Freedom to sell or lease your plot anytime</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-primary font-bold">✓</span>
                  <span className="text-foreground">No restrictions on investment period</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-primary font-bold">✓</span>
                  <span className="text-foreground">Direct access to land documentation</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-primary font-bold">✓</span>
                  <span className="text-foreground">Transparent communication at every step</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
