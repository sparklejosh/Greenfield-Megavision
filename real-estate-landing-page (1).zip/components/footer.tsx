'use client';

import Image from 'next/image';
import Link from 'next/link';
import { Mail, Phone, MessageCircle, Instagram, Facebook } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-secondary/10 border-t border-border pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-6">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 relative">
                <Image
                  src="/logo.png"
                  alt="Greenfield Megavision"
                  fill
                  className="object-contain"
                />
              </div>
              <div>
                <p className="font-bold text-sm text-foreground">GREENFIELD</p>
                <p className="text-xs text-muted">MEGAVISION</p>
              </div>
            </div>
            <p className="text-sm text-muted">
              Strategic land investment for wealth building and financial security
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold mb-4 text-foreground">Quick Links</h4>
            <ul className="space-y-2 text-sm text-muted">
              <li><Link href="/investment" className="hover:text-primary transition-colors">Investment</Link></li>
              <li><Link href="/plots" className="hover:text-primary transition-colors">Our Plots</Link></li>
              <li><Link href="/about" className="hover:text-primary transition-colors">About Us</Link></li>
              <li><Link href="/payment-plans" className="hover:text-primary transition-colors">Payment Plans</Link></li>
            </ul>
          </div>

          {/* Compliance */}
          <div>
            <h4 className="font-bold mb-4 text-foreground">Compliance</h4>
            <ul className="space-y-2 text-sm text-muted">
              <li><a href="#" className="hover:text-primary transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Terms of Service</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Legal Docs</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Certifications</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-bold mb-4 text-foreground">Get In Touch</h4>
            <div className="space-y-3">
              <a
                href="https://wa.me/2348099955884"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-muted hover:text-primary transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                WhatsApp
              </a>
              <a
                href="mailto:contact@greenfieldmegavision.com"
                className="flex items-center gap-2 text-sm text-muted hover:text-primary transition-colors"
              >
                <Mail className="w-4 h-4" />
                Email
              </a>
              <a
                href="tel:+2348099955884"
                className="flex items-center gap-2 text-sm text-muted hover:text-primary transition-colors"
              >
                <Phone className="w-4 h-4" />
                Phone
              </a>
              <a
                href="https://www.instagram.com/offical_greenfieldmegavision"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-muted hover:text-primary transition-colors"
              >
                <Instagram className="w-4 h-4" />
                Instagram
              </a>
              <a
                href="https://www.facebook.com/greenfieldmegavision"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-muted hover:text-primary transition-colors"
              >
                <Facebook className="w-4 h-4" />
                Facebook
              </a>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-border py-6"></div>

        {/* Bottom Footer */}
        <div className="flex flex-col md:flex-row items-center justify-between text-xs text-muted">
          <p>&copy; 2024 Greenfield Megavision. All rights reserved.</p>
          <div className="flex gap-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-primary transition-colors">Privacy</a>
            <a href="#" className="hover:text-primary transition-colors">Terms</a>
            <a href="#" className="hover:text-primary transition-colors">Security</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

function MessageCircleIcon(props: any) {
  return (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
    </svg>
  );
}

function InstagramIcon(props: any) {
  return (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
      <circle cx="17.5" cy="6.5" r="1.5" />
    </svg>
  );
}
