'use client'

import { Button } from '@/components/ui/button'
import { MessageCircle, X } from 'lucide-react'
import Link from 'next/link'

interface UrgencyPopupProps {
  onClose: () => void
}

export default function UrgencyPopup({ onClose }: UrgencyPopupProps) {
  const whatsappLink = "https://wa.me/2348099955884?text=Hi%20Greenfield%20Megavision!%20I'm%20interested%20in%20learning%20more%20about%20your%20land%20plots."

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 flex items-center justify-center p-4 animate-fade-in">
      {/* Modal */}
      <div className="bg-gradient-to-br from-green-500/10 via-gray-900 to-transparent border border-green-500/30 rounded-2xl p-8 md:p-10 max-w-md relative space-y-6 animate-scale-in shadow-2xl">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 hover:bg-green-500/10 rounded-lg transition-colors"
        >
          <X className="h-5 w-5 text-gray-400 hover:text-white" />
        </button>

        {/* Content */}
        <div className="space-y-4">
          <div>
            <h3 className="text-2xl font-bold text-white mb-2">
              Still Thinking?
            </h3>
            <p className="text-gray-300">
              Prices just increased recently. The next increase is coming soon.
            </p>
          </div>

          <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
            <p className="text-red-400 font-semibold text-sm">
              ⚠️ Only 7 plots left at this price level
            </p>
          </div>

          <p className="text-gray-400 text-sm">
            Smart investors are securing their spots right now. Don&apos;t miss out on this opportunity.
          </p>
        </div>

        {/* CTA Button */}
        <Link href={whatsappLink} target="_blank" rel="noopener noreferrer" className="w-full">
          <Button
            size="lg"
            className="w-full bg-green-500 hover:bg-green-600 text-black font-bold text-base px-6 rounded-lg transition-all duration-300"
          >
            <MessageCircle className="mr-2 h-5 w-5" />
            Chat Now on WhatsApp
          </Button>
        </Link>

        {/* Secondary CTA */}
        <Button
          variant="outline"
          size="lg"
          onClick={onClose}
          className="w-full border-gray-600 text-gray-300 hover:bg-gray-800/50 font-semibold"
        >
          Maybe Later
        </Button>
      </div>
    </div>
  )
}

// Add animations to globals.css
const animations = `
@keyframes fade-in {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

@keyframes scale-in {
  from {
    opacity: 0;
    transform: scale(0.95);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}

.animate-fade-in {
  animation: fade-in 0.3s ease-in-out;
}

.animate-scale-in {
  animation: scale-in 0.3s ease-out;
}
`
