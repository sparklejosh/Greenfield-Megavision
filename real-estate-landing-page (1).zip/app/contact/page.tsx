import { Navbar } from '@/components/navbar';
import { Footer } from '@/components/footer';
import { FloatingCTA } from '@/components/floating-cta';
import { Mail, Phone, MessageCircle } from 'lucide-react';

export default function Contact() {

  return (
    <>
      <Navbar />
      <main className="overflow-hidden">
        {/* Hero Section */}
        <section className="pt-24 pb-16 px-6">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">Get in Touch</h1>
            <p className="text-lg text-muted max-w-2xl mx-auto">
              Have questions? Our investment team is here to help you find the perfect opportunity.
            </p>
          </div>
        </section>

        {/* Contact Methods */}
        <section className="py-16 px-6 bg-secondary/5">
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                { icon: MessageCircle, title: 'WhatsApp', value: '+234 809 995 5884', link: 'https://wa.me/2348099955884', desc: 'Quick replies' },
                { icon: Mail, title: 'Email', value: 'contact@greenfield.com', link: 'mailto:contact@greenfield.com', desc: 'Detailed inquiries' },
                { icon: Phone, title: 'Phone', value: '+234 809 995 5884', link: 'tel:+2348099955884', desc: 'Direct call' },
              ].map((method, idx) => {
                const Icon = method.icon;
                return (
                  <a
                    key={idx}
                    href={method.link}
                    target={method.link.startsWith('http') ? '_blank' : undefined}
                    rel={method.link.startsWith('http') ? 'noopener noreferrer' : undefined}
                    className="border border-border bg-card rounded-lg p-8 text-center hover:border-primary transition-colors group"
                  >
                    <Icon className="w-8 h-8 text-primary mx-auto mb-4 group-hover:scale-110 transition-transform" />
                    <h3 className="font-bold text-foreground mb-2">{method.title}</h3>
                    <p className="text-primary font-semibold text-sm mb-2">{method.value}</p>
                    <p className="text-xs text-muted">{method.desc}</p>
                  </a>
                );
              })}
            </div>
          </div>
        </section>

        {/* Contact Form */}
        <section className="py-16 px-6">
          <div className="max-w-2xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-foreground text-center">Send Us a Message</h2>
            <form action="https://wa.me/2348099955884" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">Full Name</label>
                  <input type="text" placeholder="Your name" className="w-full px-4 py-3 border border-border bg-input rounded focus:outline-none focus:ring-2 focus:ring-primary/50" required />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">Email</label>
                  <input type="email" placeholder="your@email.com" className="w-full px-4 py-3 border border-border bg-input rounded focus:outline-none focus:ring-2 focus:ring-primary/50" required />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">Phone</label>
                <input type="tel" placeholder="+234" className="w-full px-4 py-3 border border-border bg-input rounded focus:outline-none focus:ring-2 focus:ring-primary/50" />
              </div>

              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">Subject</label>
                <select className="w-full px-4 py-3 border border-border bg-input rounded focus:outline-none focus:ring-2 focus:ring-primary/50" required>
                  <option value="">Select a subject...</option>
                  <option value="General Investment">General Investment Inquiry</option>
                  <option value="Specific Plots">Specific Plot Questions</option>
                  <option value="Payment Plans">Payment Plan Options</option>
                  <option value="Legal Documentation">Documentation & Legal</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">Message</label>
                <textarea placeholder="Tell us what you'd like to know..." rows={6} className="w-full px-4 py-3 border border-border bg-input rounded focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none" required></textarea>
              </div>

              <button type="submit" className="w-full px-6 py-3 bg-primary text-primary-foreground rounded font-semibold hover:bg-accent transition-colors">
                Send Message via WhatsApp
              </button>
            </form>
          </div>
        </section>

        {/* FAQs */}
        <section className="py-16 px-6 bg-secondary/5">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-foreground text-center">Common Questions</h2>
            <div className="space-y-6">
              {[
                { q: 'How do I start my investment?', a: 'Contact us via WhatsApp, email, or phone. Our team will guide you through the process from start to finish.' },
                { q: 'What documents do I need?', a: 'Valid ID, proof of address, and bank information. We handle everything else including legal documentation.' },
                { q: 'How long does the process take?', a: 'From contact to ownership typically takes 2-4 weeks depending on your payment plan.' },
                { q: 'Is my investment safe?', a: 'Yes. 100% verified titles, government registration, legal documentation, and escrow protection.' },
                { q: 'Can I sell my plot later?', a: 'Absolutely. Your land is a liquid asset that appreciates over time.' },
              ].map((faq, idx) => (
                <div key={idx} className="border border-border bg-card rounded-lg p-6">
                  <h3 className="font-bold text-foreground mb-2">{faq.q}</h3>
                  <p className="text-muted text-sm">{faq.a}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Final CTA */}
        <section className="py-16 px-6">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6 text-foreground">Ready to Get Started?</h2>
            <p className="text-muted mb-8 max-w-2xl mx-auto">
              Our investment team is standing by to answer all your questions and help you secure your plot today.
            </p>
            <a
              href="https://wa.me/2348099955884?text=I'm%20interested%20in%20learning%20more%20about%20Greenfield%20Megavision"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block px-8 py-3 bg-primary text-primary-foreground rounded font-semibold hover:bg-accent transition-colors"
            >
              Chat on WhatsApp Now
            </a>
          </div>
        </section>
      </main>
      <Footer />
      <FloatingCTA />
    </>
  );
}
