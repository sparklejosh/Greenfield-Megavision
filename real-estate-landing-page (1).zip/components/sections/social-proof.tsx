'use client'

import { Card } from '@/components/ui/card'
import { TrendingUp } from 'lucide-react'

export default function SocialProofSection() {
  const testimonials = [
    {
      id: 1,
      name: 'Chukwu Okafor',
      oldPrice: '₦1,200,000',
      newPrice: '₦3,100,000',
      increase: '158%',
      timeframe: '18 months',
    },
    {
      id: 2,
      name: 'Amara Johnson',
      oldPrice: '₦850,000',
      newPrice: '₦2,550,000',
      increase: '200%',
      timeframe: '22 months',
    },
    {
      id: 3,
      name: 'Emeka Nwankwo',
      oldPrice: '₦1,500,000',
      newPrice: '₦4,200,000',
      increase: '180%',
      timeframe: '20 months',
    },
  ]

  return (
    <section className="bg-gradient-to-b from-green-950/20 to-transparent py-20 md:py-32">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            From Affordable to Premium—<span className="text-green-400">In Months</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Watch your investment grow while the market works for you
          </p>
        </div>

        {/* Stats Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-6 text-center">
            <div className="text-3xl font-bold text-green-400 mb-2">2-3x</div>
            <p className="text-gray-400 text-sm">Price appreciation</p>
          </div>
          <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-6 text-center">
            <div className="text-3xl font-bold text-green-400 mb-2">100+</div>
            <p className="text-gray-400 text-sm">Happy investors</p>
          </div>
          <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-6 text-center">
            <div className="text-3xl font-bold text-green-400 mb-2">99%</div>
            <p className="text-gray-400 text-sm">Title verified</p>
          </div>
          <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-6 text-center">
            <div className="text-3xl font-bold text-green-400 mb-2">18mo</div>
            <p className="text-gray-400 text-sm">Avg. returns time</p>
          </div>
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((testimonial) => (
            <Card
              key={testimonial.id}
              className="bg-gradient-to-br from-green-500/10 via-transparent to-transparent border border-green-500/20 hover:border-green-500/50 transition-all duration-300 backdrop-blur-sm p-6 group"
            >
              <div className="space-y-4">
                {/* Icon */}
                <div className="inline-flex items-center justify-center w-12 h-12 bg-green-500/20 rounded-lg group-hover:bg-green-500/30 transition-colors">
                  <TrendingUp className="h-6 w-6 text-green-400" />
                </div>

                {/* Content */}
                <div>
                  <p className="text-gray-400 text-sm mb-4">
                    Bought at <span className="font-bold text-green-300">{testimonial.oldPrice}</span>
                  </p>
                  <p className="text-white font-bold mb-2">Now worth:</p>
                  <p className="text-3xl font-bold text-green-400 mb-2">
                    {testimonial.newPrice}
                  </p>
                  <div className="flex items-baseline gap-2">
                    <span className="text-xl font-bold text-green-300">+{testimonial.increase}</span>
                    <span className="text-xs text-gray-500">in {testimonial.timeframe}</span>
                  </div>
                </div>

                {/* Investor Name */}
                <p className="text-gray-500 text-sm pt-4 border-t border-green-500/10">
                  — {testimonial.name}
                </p>
              </div>
            </Card>
          ))}
        </div>

        {/* Bottom Message */}
        <div className="mt-12 text-center">
          <p className="text-gray-400 text-base md:text-lg">
            <span className="text-green-400 font-bold">Limited plots remaining</span> at current prices
          </p>
        </div>
      </div>
    </section>
  )
}
