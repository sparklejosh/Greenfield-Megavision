'use client'

import { Card } from '@/components/ui/card'
import { Palette, Pencil } from 'lucide-react'

export default function CustomizationSection() {
  return (
    <section className="py-20 md:py-32 bg-gradient-to-b from-transparent to-green-950/20">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div>
              <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
                Build Your<br />
                <span className="text-green-400">Dream Home</span>
                <br />Your Way
              </h2>
              <p className="text-gray-400 text-lg leading-relaxed">
                No forced designs. No rigid layouts. Complete freedom to build exactly what suits your lifestyle and vision.
              </p>
            </div>

            {/* Features */}
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="inline-flex items-center justify-center w-10 h-10 bg-green-500/20 rounded-lg flex-shrink-0">
                  <Palette className="h-5 w-5 text-green-400" />
                </div>
                <div>
                  <h3 className="font-bold text-white mb-1">
                    Custom Architecture Freedom
                  </h3>
                  <p className="text-gray-400 text-sm">
                    Design your property exactly as you envision it—modern, traditional, or hybrid styles.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="inline-flex items-center justify-center w-10 h-10 bg-green-500/20 rounded-lg flex-shrink-0">
                  <Pencil className="h-5 w-5 text-green-400" />
                </div>
                <div>
                  <h3 className="font-bold text-white mb-1">
                    Modern Estate Planning
                  </h3>
                  <p className="text-gray-400 text-sm">
                    Professional design services available to help optimize your plot layout.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right - Visual Cards */}
          <div className="relative">
            <div className="grid grid-cols-2 gap-4">
              <Card className="bg-gradient-to-br from-green-500/10 to-transparent border border-green-500/20 p-6 h-40 flex items-end">
                <div>
                  <p className="text-green-400 text-sm font-semibold mb-1">Modern</p>
                  <p className="text-white font-bold text-lg">Contemporary</p>
                </div>
              </Card>
              <Card className="bg-gradient-to-br from-green-500/10 to-transparent border border-green-500/20 p-6 h-40 flex items-end">
                <div>
                  <p className="text-green-400 text-sm font-semibold mb-1">Luxury</p>
                  <p className="text-white font-bold text-lg">Victorian</p>
                </div>
              </Card>
              <Card className="bg-gradient-to-br from-green-500/10 to-transparent border border-green-500/20 p-6 h-40 flex items-end col-span-2">
                <div>
                  <p className="text-green-400 text-sm font-semibold mb-1">Your Style</p>
                  <p className="text-white font-bold text-lg">Your Choice</p>
                </div>
              </Card>
            </div>

            {/* Glow Effect */}
            <div className="absolute -top-20 -right-20 w-40 h-40 bg-green-500/5 rounded-full blur-3xl pointer-events-none"></div>
          </div>
        </div>
      </div>
    </section>
  )
}
