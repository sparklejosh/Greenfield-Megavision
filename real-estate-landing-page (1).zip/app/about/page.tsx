import { Navbar } from '@/components/navbar';
import { Footer } from '@/components/footer';
import { FloatingCTA } from '@/components/floating-cta';

export default function About() {
  return (
    <>
      <Navbar />
      <main className="overflow-hidden">
        {/* Hero Section */}
        <section className="pt-24 pb-16 px-6">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">About Greenfield Megavision</h1>
            <p className="text-lg text-muted max-w-2xl mx-auto">
              10+ years of excellence in premium land investment and community development. Trusted by 500+ investors nationwide.
            </p>
          </div>
        </section>

        {/* Our Story */}
        <section className="py-16 px-6 bg-secondary/5">
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl font-bold mb-6 text-foreground">Our Story</h2>
                <p className="text-muted mb-4 leading-relaxed">
                  Founded in 2014, Greenfield Megavision emerged from a simple vision: to democratize premium land investment and create pathways to wealth for everyday Nigerians.
                </p>
                <p className="text-muted mb-4 leading-relaxed">
                  What started as a passion project has grown into a trusted brand managing over ₦2 billion in investment capital across multiple premium estates.
                </p>
                <p className="text-muted leading-relaxed">
                  Today, we&apos;re not just selling land—we&apos;re building communities and creating generational wealth for our investors.
                </p>
              </div>
              <div className="bg-gradient-to-br from-primary/20 to-accent/20 rounded-lg p-12 flex items-center justify-center">
                <div className="text-center">
                  <p className="text-5xl font-bold text-primary mb-2">10+</p>
                  <p className="text-foreground font-semibold">Years in Business</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Core Values */}
        <section className="py-16 px-6">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-foreground text-center">Our Core Values</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                { title: 'Transparency', desc: 'We believe in complete honesty in every transaction' },
                { title: 'Excellence', desc: 'Premium quality in every aspect of our service' },
                { title: 'Integrity', desc: 'Your trust is our most valuable asset' },
              ].map((value, idx) => (
                <div key={idx} className="border border-border bg-card rounded-lg p-8">
                  <h3 className="text-xl font-bold mb-3 text-foreground">{value.title}</h3>
                  <p className="text-muted">{value.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Stats */}
        <section className="py-16 px-6 bg-secondary/5">
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {[
                { label: 'Investors', value: '500+' },
                { label: 'Investment Volume', value: '₦2B+' },
                { label: 'Avg ROI', value: '156%' },
                { label: 'Satisfaction Rate', value: '98%' },
              ].map((stat, idx) => (
                <div key={idx} className="text-center">
                  <p className="text-3xl md:text-4xl font-bold text-primary mb-2">{stat.value}</p>
                  <p className="text-muted text-sm">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-16 px-6">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6 text-foreground">Ready to Join Our Community?</h2>
            <a
              href="https://wa.me/2348099955884"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block px-8 py-3 bg-primary text-primary-foreground rounded font-semibold hover:bg-accent transition-colors"
            >
              Chat with Us on WhatsApp
            </a>
          </div>
        </section>
      </main>
      <Footer />
      <FloatingCTA />
    </>
  );
}
