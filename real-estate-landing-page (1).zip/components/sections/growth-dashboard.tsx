'use client';

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

export function GrowthDashboard() {
  const growthData = [
    { month: 'Month 0', value: 100, label: 'Initial Investment' },
    { month: 'Month 6', value: 115, label: 'First Growth' },
    { month: 'Month 12', value: 135, label: 'Steady Growth' },
    { month: 'Month 18', value: 156, label: 'Target Return' },
    { month: 'Month 24', value: 180, label: 'Extended Horizon' },
  ];

  const investorProfiles = [
    {
      name: 'Chisom O.',
      investment: '₦2M',
      timeline: '18 months',
      return: '₦3.12M',
      profit: '₦1.12M (56%)',
      image: '👨‍💼',
    },
    {
      name: 'Amara L.',
      investment: '₦5M',
      timeline: '18 months',
      return: '₦7.8M',
      profit: '₦2.8M (56%)',
      image: '👩‍💼',
    },
    {
      name: 'Tunde A.',
      investment: '₦10M',
      timeline: '18 months',
      return: '₦15.6M',
      profit: '₦5.6M (56%)',
      image: '👨‍💼',
    },
  ];

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 rounded-lg shadow-lg border border-primary/20">
          <p className="text-sm font-semibold text-foreground">{payload[0].payload.label}</p>
          <p className="text-primary font-bold">{payload[0].value}%</p>
        </div>
      );
    }
    return null;
  };

  return (
    <section className="py-20 md:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="section-heading mb-4">Your Growth Journey</h2>
          <p className="section-subheading mx-auto">
            Watch how your investment grows over 18-24 months
          </p>
        </div>

        {/* Growth Chart */}
        <div className="bg-gradient-to-br from-primary/5 via-white to-accent/5 rounded-2xl p-8 mb-16 border border-border animate-slide-up">
          <h3 className="text-2xl font-bold mb-8 text-foreground">Investment Growth Trajectory</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={growthData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="month" stroke="#6b7280" />
              <YAxis stroke="#6b7280" />
              <Tooltip content={<CustomTooltip />} />
              <Line
                type="monotone"
                dataKey="value"
                stroke="#10b981"
                strokeWidth={3}
                dot={{ fill: '#10b981', r: 6 }}
                activeDot={{ r: 8 }}
                isAnimationActive={true}
              />
            </LineChart>
          </ResponsiveContainer>
          <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4">
            {growthData.map((point, index) => (
              <div key={index} className="text-center p-4 bg-white rounded-lg border border-border">
                <p className="text-xs text-muted mb-1">{point.month}</p>
                <p className="text-lg font-bold text-primary">{point.value}%</p>
              </div>
            ))}
          </div>
        </div>

        {/* Investor Profiles */}
        <div className="mb-16 animate-slide-up">
          <h3 className="text-2xl font-bold mb-8 text-foreground">Real Investor Returns</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {investorProfiles.map((investor, index) => (
              <div key={index} className="card-premium-lg">
                <div className="flex items-start justify-between mb-4">
                  <div className="text-5xl">{investor.image}</div>
                  <div className="text-right">
                    <p className="font-semibold text-foreground">{investor.name}</p>
                    <p className="text-xs text-muted">{investor.timeline}</p>
                  </div>
                </div>

                <div className="space-y-3 mb-6 py-6 border-t border-b border-border">
                  <div className="flex justify-between items-center">
                    <span className="text-muted text-sm">Investment:</span>
                    <span className="font-bold text-foreground">{investor.investment}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted text-sm">Return Value:</span>
                    <span className="font-bold text-primary">{investor.return}</span>
                  </div>
                </div>

                <div className="bg-primary/10 rounded-lg p-4 border border-primary/20">
                  <p className="text-sm text-muted mb-1">Total Profit</p>
                  <p className="text-xl font-bold text-primary">{investor.profit}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Key Insights */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-fade-in">
          <div className="card-premium-lg">
            <h4 className="text-xl font-bold mb-4 text-foreground">Why Land Appreciates</h4>
            <ul className="space-y-3">
              <li className="flex gap-3">
                <span className="text-primary font-bold">✓</span>
                <span className="text-foreground">Limited supply, increasing demand</span>
              </li>
              <li className="flex gap-3">
                <span className="text-primary font-bold">✓</span>
                <span className="text-foreground">Urbanization and infrastructure development</span>
              </li>
              <li className="flex gap-3">
                <span className="text-primary font-bold">✓</span>
                <span className="text-foreground">Population growth drives location value</span>
              </li>
            </ul>
          </div>

          <div className="card-premium-lg">
            <h4 className="text-xl font-bold mb-4 text-foreground">Investment Timeline</h4>
            <div className="space-y-4">
              <div>
                <p className="text-sm font-semibold text-primary mb-1">0-6 Months</p>
                <p className="text-sm text-muted">Document registration & legal verification</p>
              </div>
              <div>
                <p className="text-sm font-semibold text-primary mb-1">6-18 Months</p>
                <p className="text-sm text-muted">Estate development & value accumulation</p>
              </div>
              <div>
                <p className="text-sm font-semibold text-primary mb-1">18+ Months</p>
                <p className="text-sm text-muted">Monetization & resale opportunities</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
