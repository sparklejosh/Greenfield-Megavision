import { Navbar } from '@/components/navbar';
import { Footer } from '@/components/footer';
import { FloatingCTA } from '@/components/floating-cta';
import Link from 'next/link';

export default function Investment() {
  return (
    <>
      <Navbar />
      <main className="overflow-hidden">
        {/* Hero Section */}
        <section className="pt-24 pb-16 px-6">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">Investment Opportunity</h1>
            <p className="text-lg text-muted max-w-2xl mx-auto">
              Proven returns, verified titles, and transparent pricing. Join 500+ investors building wealth.
            </p>
          </div>
        </section>

        {/* Investment Highlights */}
        <section className="py-16 px-6 bg-secondary/5">
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
              {[
                { title: 'Proven Returns', value: '156%', desc: 'Average appreciation in 18-24 months' },
                { title: 'Tangible Asset', value: 'Real Value', desc: 'Physical land with verified titles' },
                { title: 'Low Risk', value: '0% Volatility', desc: 'No market fluctuations' },
              ].map((item, idx) => (
                <div key={idx} className="border border-border bg-card rounded-lg p-8 text-center">
                  <p className="text-4xl font-bold text-primary mb-2">{item.value}</p>
                  <h3 className="text-lg font-semibold text-foreground mb-2">{item.title}</h3>
                  <p className="text-muted text-sm">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Investment Comparison */}
        <section className="py-16 px-6">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-foreground text-center">How We Compare</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-4 px-4 text-foreground font-semibold">Factor</th>
                    <th className="text-left py-4 px-4 text-primary font-semibold">Greenfield Land</th>
                    <th className="text-left py-4 px-4 text-muted">Traditional Real Estate</th>
                    <th className="text-left py-4 px-4 text-muted">Stock Market</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { factor: 'Average ROI', greenfield: '156%', other1: '45-60%', other2: '20-35%' },
                    { factor: 'Time to Profit', greenfield: '18-24 months', other1: '5+ years', other2: '5+ years' },
                    { factor: 'Risk Level', greenfield: 'Low', other1: 'Medium', other2: 'High' },
                    { factor: 'Liquidity', greenfield: 'High', other1: 'Medium', other2: 'Very High' },
                    { factor: 'Tangible Asset', greenfield: 'Yes', other1: 'Yes', other2: 'No' },
                    { factor: 'Market Volatility', greenfield: 'None', other1: 'Medium', other2: 'High' },
                  ].map((row, idx) => (
                    <tr key={idx} className="border-b border-border/50">
                      <td className="py-4 px-4 text-foreground font-medium">{row.factor}</td>
                      <td className="py-4 px-4 text-primary font-semibold">{row.greenfield}</td>
                      <td className="py-4 px-4 text-muted">{row.other1}</td>
                      <td className="py-4 px-4 text-muted">{row.other2}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </section>

        {/* Real Returns */}
        <section className="py-16 px-6 bg-secondary/5">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-foreground text-center">Real Investor Returns</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                { name: 'Chidi O.', investment: '₦1.5M', profit: '₦2.34M', roi: '156%', months: '20 months' },
                { name: 'Grace A.', investment: '₦2.8M', profit: '₦5.6M', roi: '200%', months: '18 months' },
                { name: 'Tunde M.', investment: '₦1M', profit: '₦1.8M', roi: '180%', months: '22 months' },
              ].map((investor, idx) => (
                <div key={idx} className="border border-border bg-card rounded-lg p-8">
                  <h3 className="font-semibold text-foreground mb-4">{investor.name}</h3>
                  <div className="space-y-3">
                    <div>
                      <p className="text-xs text-muted mb-1">Initial Investment</p>
                      <p className="font-semibold text-foreground">{investor.investment}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted mb-1">Profit Gained</p>
                      <p className="font-semibold text-primary text-lg">{investor.profit}</p>
                    </div>
                    <div className="flex justify-between pt-4 border-t border-border">
                      <div>
                        <p className="text-xs text-muted">ROI</p>
                        <p className="font-semibold text-foreground">{investor.roi}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted">Timeline</p>
                        <p className="font-semibold text-foreground">{investor.months}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Risk Mitigation */}
        <section className="py-16 px-6">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-foreground text-center">Why This Investment is Safe</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {[
                { title: 'Legal Protection', items: ['100% verified titles', 'Full documentation', 'Government registration'] },
                { title: 'Financial Security', items: ['Transparent pricing', 'Escrow protection', 'No hidden charges'] },
                { title: 'Physical Security', items: ['24/7 surveillance', 'Gated community', 'Professional management'] },
                { title: 'Investor Support', items: ['Dedicated account manager', 'Regular updates', '24/7 support'] },
              ].map((section, idx) => (
                <div key={idx} className="border border-border bg-card rounded-lg p-8">
                  <h3 className="text-lg font-bold text-foreground mb-6">{section.title}</h3>
                  <ul className="space-y-3">
                    {section.items.map((item, i) => (
                      <li key={i} className="flex items-center text-muted text-sm">
                        <span className="w-2 h-2 bg-primary rounded-full mr-3 flex-shrink-0" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-16 px-6 bg-secondary/5">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6 text-foreground">Ready to Start?</h2>
            <p className="text-muted mb-8 max-w-2xl mx-auto">
              View available plots or contact us for personalized investment guidance tailored to your goals.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/plots" className="px-8 py-3 bg-primary text-primary-foreground rounded font-semibold hover:bg-accent transition-colors">
                View Available Plots
              </Link>
              <Link href="/contact" className="px-8 py-3 border-2 border-primary text-primary rounded font-semibold hover:bg-primary hover:text-primary-foreground transition-colors">
                Contact Us
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <FloatingCTA />
    </>
  );
}
