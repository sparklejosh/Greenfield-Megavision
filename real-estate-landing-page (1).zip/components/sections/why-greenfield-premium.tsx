'use client';

import { Shield, TrendingUp, Lock, Users, Zap } from 'lucide-react';

export function WhyGreenfield() {
  const pillars = [
    {
      icon: Shield,
      title: 'Verified Legal Titles',
      description: 'Every plot comes with verified titles, legal documentation, and government registration. No disputes, no surprises.',
      details: ['✓ Government Registered', '✓ Surveyed & Mapped', '✓ Title Insurance'],
    },
    {
      icon: TrendingUp,
      title: 'Proven Appreciation',
      description: '156% average appreciation in 18-24 months, backed by real investor returns and documented case studies.',
      details: ['✓ 18-24 Month ROI', '✓ 500+ Verified Investors', '✓ Transparent Documentation'],
    },
    {
      icon: Lock,
      title: 'Secure Infrastructure',
      description: 'Gated community, 24/7 security, modern amenities, and professional estate management. Your investment is protected.',
      details: ['✓ Gated & Secured', '✓ 24/7 Monitoring', '✓ Professional Management'],
    },
    {
      icon: Users,
      title: 'Active Community',
      description: 'Growing community of investors, developers, and business owners creating real value and continuous demand.',
      details: ['✓ Community Events', '✓ Business Network', '✓ Shared Growth'],
    },
    {
      icon: Zap,
      title: 'Flexible Payment Plans',
      description: 'Multiple payment options designed to fit your financial situation. Start small, grow your investment.',
      details: ['✓ Installment Plans', '✓ Zero Hidden Costs', '✓ Transparent Pricing'],
    },
  ];

  return (
    <section id="why-greenfield" className="py-20 md:py-32 bg-gradient-to-b from-primary/5 to-white">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="section-heading mb-4">Why Smart Investors Choose Greenfield</h2>
          <p className="section-subheading mx-auto">
            Five core pillars that make us Nigeria&apos;s most trusted land investment platform
          </p>
        </div>

        {/* Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 animate-slide-up">
          {pillars.map((pillar, index) => {
            const Icon = pillar.icon;
            return (
              <div key={index} className="card-premium group">
                {/* Icon */}
                <div className="mb-4 p-3 bg-primary/10 rounded-lg w-fit group-hover:bg-primary/20 transition-colors">
                  <Icon className="w-6 h-6 text-primary" />
                </div>

                {/* Title */}
                <h3 className="text-lg font-bold mb-2 text-foreground">{pillar.title}</h3>

                {/* Description */}
                <p className="text-sm text-muted mb-4 flex-grow">{pillar.description}</p>

                {/* Details */}
                <div className="space-y-2 pt-4 border-t border-border">
                  {pillar.details.map((detail, detailIndex) => (
                    <p key={detailIndex} className="text-xs text-primary font-medium">
                      {detail}
                    </p>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom Stats */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-4 gap-8 animate-fade-in">
          <div className="text-center">
            <p className="text-4xl font-bold text-primary mb-2">500+</p>
            <p className="text-muted">Happy Investors</p>
          </div>
          <div className="text-center">
            <p className="text-4xl font-bold text-primary mb-2">₦2B+</p>
            <p className="text-muted">Total Investment</p>
          </div>
          <div className="text-center">
            <p className="text-4xl font-bold text-primary mb-2">98%</p>
            <p className="text-muted">Satisfaction Rate</p>
          </div>
          <div className="text-center">
            <p className="text-4xl font-bold text-primary mb-2">10+</p>
            <p className="text-muted">Years Experience</p>
          </div>
        </div>
      </div>
    </section>
  );
}
